# Connector_Wire.pretty
Footprints for connecting wires directly to the PCB
